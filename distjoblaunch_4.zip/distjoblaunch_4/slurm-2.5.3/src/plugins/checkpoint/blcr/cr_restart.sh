#!/bin/sh
exec /bin/cr_restart $1
