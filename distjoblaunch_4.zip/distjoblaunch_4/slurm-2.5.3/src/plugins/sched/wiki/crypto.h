/*****************************************************************************\
 *  crypto.h - DES cryptographic routines.
 *****************************************************************************
 *  Produced by Cluster Resources, Inc., no rights reserved.
\*****************************************************************************/
#include <stdint.h>

extern void	checksum( char *sum, const char *key, const char *buf );
