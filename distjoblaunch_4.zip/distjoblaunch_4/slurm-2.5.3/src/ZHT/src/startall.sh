./zhtserver -z zht.conf -n neighbor.conf -p 50000&
./zhtserver -z zht.conf -n neighbor.conf -p 50001&
./zhtserver -z zht.conf -n neighbor.conf -p 50002&
./zhtserver -z zht.conf -n neighbor.conf -p 50003&
./zhtserver -z zht.conf -n neighbor.conf -p 50004&
./zhtserver -z zht.conf -n neighbor.conf -p 50005&
./zhtserver -z zht.conf -n neighbor.conf -p 50006&
./zhtserver -z zht.conf -n neighbor.conf -p 50007&
