pkill zhtserver
